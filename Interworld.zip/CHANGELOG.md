# Historial de Cambios

## [1.0.0] - 2025-08-10
- Versión inicial del proyecto.
