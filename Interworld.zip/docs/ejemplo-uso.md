# Ejemplo de uso

Aquí puedes documentar cómo se utiliza el proyecto con ejemplos prácticos.
